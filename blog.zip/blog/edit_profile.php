<?php
session_start();
?>

<html>
<head>

<style>
body{
	background : url(images/background.jpg);
	background-size: 100% 100%;
}
.error{
			color:red;
		}
		body{
			background-repeat:no-repeat;
			background-size:100%;
			background-attachment:fixed;
		}
		.sub2{
			background-color:#663500;
			color:white;
			padding:20px;
			padding-right:50px;
			padding-left:50px;
			margin:auto;
			width:20%;
			border-width:5px;
			border-color:white;
		}
		#sub1{
			
			color:#663500;
			margin-left:auto;
			margin-right:auto;
		}
		.inputclass{
			width:100%;
			margin:auto;
			height:34px;
			border-radius:5px;
		}
	
	.backbutton{
	background-color:#663500;
	width:100px;
	height:40px;
	float:right;
}
</style>

<script type="text/javascript">
		function validateForm2() {
			var re=/^[\w]+$/;
			var me=/^[A-Za-z]{1}[0-9]{2}[A-Za-z]{2}[0-9]{3}$/;
			var x = document.getElementById("B").value;
			var y = document.getElementById("C").value;
			var x2 = document.forms["myForm"]["email"].value;
			var atpos = x2.indexOf("@");
			var dotpos = x2.lastIndexOf(".");
			
   			if (x == null || x == "") {
        		alert("USER_NAME must be filled out");
        		return false;
   			}
			else if(!re.test(x))
			{
				alert("Error:USER_NAME contains INVALID characters");
				return false;
			}
			
			
   			
        	else if(y == null || y == ""){
        		alert("PASSWORD is must");
        		return false;
        	}
			
        	
			
			else if (atpos<1 || dotpos<atpos+2 || dotpos+2>=x2.length) {
				alert("Not a valid e-mail address");
				return false;
			}
			else{
				return true;
			}
		}
		
	</script>

<body>

<?php

$nameofuser= $_SESSION['username'];
$con = mysqli_connect("localhost","root","","blog");
if (!$con)
  {
  die('Could not connect: ' . mysqli_error());
  }
  $query= "SELECT admin FROM blogger_info WHERE blogger_username='$nameofuser'";
  $result=mysqli_query($con,$query);
  $row = mysqli_fetch_assoc($result);
  if($row['admin']==1)
  {
echo'<form name="myForm" enctype="multipart/form-data" onsubmit="" action="admin.php" method="post">';
	echo'<input type="submit"value="Back" name="Back" class="backbutton"/>';
	echo '</form>';
  }
  else{
	  echo'<form name="myForm" enctype="multipart/form-data" onsubmit="" action="welcome.php" method="post">';
	echo'<input type="submit"value="Back" name="Back" class="backbutton"/>';
	echo '</form>';
  }
  ?>
  
	<?php
	if(strcmp($_SESSION["edit_status_username"],"Not Edited")==0){
		?><script>alert("Username already used");</script><?php
		$_SESSION["edit_status_username"]="Allow";
	}
		
	?>
	
	<?php
		$old_username= $_SESSION['username'];
		$con = mysqli_connect("localhost","root","","blog");
if (!$con)
  {
  die('Could not connect: ' . mysqli_error());
  }
  
  $edit_profile_query= "SELECT blogger_username , blogger_password, blogger_email,blogger_updated_date FROM blogger_info WHERE blogger_username='$old_username'";
  $edit_profile_result= mysqli_query($con, $edit_profile_query);
  $edit_profile_row = mysqli_fetch_assoc($edit_profile_result);
  $old_name= $edit_profile_row['blogger_username'];
  $old_password= $edit_profile_row['blogger_password'];
  $old_email= $edit_profile_row['blogger_email'];
  mysqli_close($con);
	
	?>
	
	
		<H1 align="center" id="sub1" style="color: darkbrown"><B><U>EDIT YOUR PROFILE</B></U></H1>
		<p  align="center" id="sub1"><b>The field with ' <span style = "color:#ff0000">*</span> ' mark is required</b></p>
		<form name="myForm" onsubmit="return validateForm2()" action="EditBloggerInfo.php" method="post">
		<input type="hidden" name="submitted" value="true" />
		
			<div class="sub2" >
			
				
				
					User Name<span class="error">*</span><br>
					
				 <input type="text" class="inputclass" name="username" id="B" value='<?php echo $old_name;?>' onFocus="this.value=''"/><br><br><br>
			
			
					Password<span class="error">*</span> <br>
						 <input type="text" class="inputclass" value='<?php echo $old_password;?>' name="password" id="C"/><br><br><br>
					
					
						Email<br>
							 <input type="text" name="email" value='<?php echo $old_email;?>' class="inputclass"/> <br>
			<p align="center">
				<input type="submit"value="Update Profile" name="UpdateProfile"/>
				<input type="reset" value="Reset" />
			</p>
			</div>
		</form>
		

</body>
</html>