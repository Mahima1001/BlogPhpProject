<?php
session_start();
?>
<html>
<body>
<?php
$blogid = $_POST['blogid'];

$con = mysqli_connect("localhost","root","","blog");
if (!$con)
  {
  die('Could not connect: ' . mysqli_error());
  }
  
  

	$fetch_query="SELECT blog_id,blogger_name,blog_title,blog_desc,blog_category,blog_author,blog_date,blog_day,blog_image FROM temp_table where blog_id='$blogid'";
	$fetch_result=mysqli_query($con,$fetch_query);
	$fetch_row= mysqli_fetch_assoc($fetch_result);
	$fetch_blog_id=$fetch_row["blog_id"];
	$fetch_blogger_name=$fetch_row["blogger_name"];
	$fetch_blog_title=$fetch_row["blog_title"];
	$fetch_blog_desc=$fetch_row["blog_desc"];
	$fetch_blog_category=$fetch_row["blog_category"];
	$fetch_blog_author=$fetch_row["blog_author"];
	$fetch_blog_date=$fetch_row["blog_date"];
	$fetch_blog_day=$fetch_row["blog_day"];
	$fetch_blog_image=$fetch_row["blog_image"];
	
	
	$edit_or_new_query="SELECT updated FROM check_blog where blog_id='$blogid'";
	$edit_or_new_result=mysqli_query($con,$edit_or_new_query);
	$edit_or_new_row= mysqli_fetch_assoc($edit_or_new_result);
	if($edit_or_new_row["updated"]==0){
	
	$query2="SELECT blogger_id FROM blogger_info where blogger_username='$fetch_blogger_name'";
	$result2=mysqli_query($con,$query2);
	
	$row = mysqli_fetch_assoc($result2);
	$bloggeridfromblogger_info=$row["blogger_id"];
  $query3="INSERT INTO blog_master(blogger_id,blog_title,blog_desc,blog_category,blog_author,blog_is_active,creation_date,updated_date,blog_day) values ('$bloggeridfromblogger_info','$fetch_blog_title','$fetch_blog_desc','$fetch_blog_category','$fetch_blog_author',1,'$fetch_blog_date','$fetch_blog_date','$fetch_blog_day')";
  $result3=mysqli_query($con,$query3);
  
  $query4="Select blog_id from blog_master where blog_title='$fetch_blog_title'";
  $result4=mysqli_query($con,$query4);
  
  $row4 = mysqli_fetch_assoc($result4);
  $blogid_from_blogmaster=$row4["blog_id"];
  
  $query5="INSERT INTO blog_detail(blog_id,blog_detail_image) values ('$blogid_from_blogmaster','$fetch_blog_image')";
  $result5=mysqli_query($con,$query5);
  
  $query6="DELETE FROM check_blog where blog_id='$blogid'";
  $result6=mysqli_query($con,$query6);
  
  $delete_query="DELETE FROM temp_table where blog_id='$blogid'";
  $delete_result=mysqli_query($con,$delete_query);
  }
  
  
  else if($edit_or_new_row["updated"]==1){
	  $query_update="SELECT old_title FROM check_blog WHERE blog_id='$blogid'";
	  $result_update=mysqli_query($con,$query_update);
	  $row_update=mysqli_fetch_assoc($result_update);
	  $oldtitle2= $row_update["old_title"];
	  
	  $query_id= "SELECT blog_id FROM blog_master where blog_title='$oldtitle2'";
	  $result_id=mysqli_query($con,$query_id);
	  $row_id=mysqli_fetch_assoc($result_id);
	  
	  $blog_id_fetch=$row_id["blog_id"];
	  
	  $update_query= "UPDATE blog_master SET blog_title='$fetch_blog_title',blog_desc='$fetch_blog_desc',blog_category='$fetch_blog_category',blog_author='$fetch_blog_author',blog_day='$fetch_blog_day',updated_date='$fetch_blog_date' WHERE blog_id='$blog_id_fetch'";
	  $update_result=mysqli_query($con,$update_query);
	  
	  $update_image_query="UPDATE blog_detail SET blog_detail_image='$fetch_blog_image' where blog_id='$blog_id_fetch'";
	  $update_image_result=mysqli_query($con,$update_image_query);
	  
	   $query6="DELETE FROM check_blog where blog_id='$blogid'";
  $result6=mysqli_query($con,$query6);
  
  $delete_query="DELETE FROM temp_table where blog_id='$blogid'";
  $delete_result=mysqli_query($con,$delete_query);
  }
  else{
	  
  }
	  header("Location:admin.php");

mysqli_close($con);
?>
</body>
</html>