<?php
session_start();
?>

<?php
session_unset();
session_destroy();
?>

<?php
session_start();
$_SESSION['login']="";
header("location:mainpage.php");
?>