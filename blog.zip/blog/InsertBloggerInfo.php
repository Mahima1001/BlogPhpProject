<?php
session_start();
?>
<html>
<body>
<?php
$con = mysqli_connect("localhost","root","","blog");
if (!$con)
  {
  die('Could not connect: ' . mysqli_error());
  }
//mysql_select_db("blog", $con);
 
  $name=$_POST['username'];
  $pwd=$_POST['password'];
  $email=$_POST['email'];
  
  $query="SELECT blogger_username FROM blogger_info where blogger_username='$name'";
  $result=mysqli_query($con,$query);
  $num=mysqli_num_rows($result);
  if($num > 0)
  {
	  
	  $_SESSION["check"]="Account not created";
	  header("Location:signup.php");
	  
  }
  else{
  $sqlinsert="INSERT INTO blogger_info(blogger_username,blogger_password,blogger_email,blogger_is_active,blogger_creation_date,blogger_updated_date,admin,is_image_uploaded) VALUES ('$name','$pwd','$email',1,CURDATE(),CURDATE(),0,0)";
  $_SESSION['blogger_image']="";
  if(!mysqli_query($con,$sqlinsert)){
	 die('error inserting new record') ;
	 
  }else
  
  {
	  $_SESSION['username']=$name;
	  $_SESSION["check"]="Account created successfully";
	  header("Location:signup.php");
}
  }
 
mysqli_close($con);
?>

</body>
</html>
