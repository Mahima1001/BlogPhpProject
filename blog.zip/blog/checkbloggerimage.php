<?php
session_start();
?>

<html>
<body>
<?php
$con = mysqli_connect("localhost","root","","blog");
if (!$con)
  {
  die('Could not connect: ' . mysqli_error());
  }
  $query="Select blogger_image from blogger_info where blogger_id=64";
  $result2=mysqli_query($con,$query);
	
	$row = mysqli_fetch_assoc($result2);
	
	$sImage=$row['blogger_image'];
	
	echo '<img style="width:100%; height:100%;" src="' . $sImage . ' " alt="Your Image"/>';
	mysqli_close($con);
?>
</body>
</html>