<?php
session_start();
?>
<html>
<head>
<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<style>
body{
	background : url(images/background.jpg);
	background-size: 100% 100%;
	background-attachment: fixed;
}

.design{
	border: 5px solid black;
	
	float:right;
	
}

tr, th,td{
	border: 2px solid black;
	 padding: 15px;
	 font-size:25px;
	 text-align:center;
	 margin-left:10px;
	 margin-right:10px;
}

.both{
	margin:auto;
	text-align:center;
}

.image{
	width:200px;
	height:230px;
	float:left;
	margin-left:200px;
}

.table{
	float:right;
	width:650px;
	margin-right:200px;
}
.display{
	display:block;
}

</style>
</head>

<body>
<?php

$nameofuser= $_SESSION['username'];
$con = mysqli_connect("localhost","root","","blog");
if (!$con)
  {
  die('Could not connect: ' . mysqli_error());
  }
  $query= "SELECT admin FROM blogger_info WHERE blogger_username='$nameofuser'";
  $result=mysqli_query($con,$query);
  $row = mysqli_fetch_assoc($result);
  if($row['admin']==1)
  {
	echo'<a href="admin.php"><span class="glyphicon glyphicon-arrow-left" style= "color:black; font-size:35px;"></span></a>';
  }
  else
  {
	  echo'<a href="welcome.php"><span class="glyphicon glyphicon-arrow-left" style= "color:black; font-size:35px;"></span></a>';
  }
  ?>

<?php

$username= $_SESSION['username'];
$con = mysqli_connect("localhost","root","","blog");
if (!$con)
  {
  die('Could not connect: ' . mysqli_error());
  }
  
  $query = "SELECT blogger_id , blogger_username , blogger_email , blogger_creation_date , blogger_updated_date FROM blogger_info where blogger_username= '$username'";
  $result=mysqli_query($con,$query);
  $row = mysqli_fetch_assoc($result);
  $id= $row["blogger_id"];
  $name= $row["blogger_username"];
  $email= $row['blogger_email'];
  $creation_date= $row["blogger_creation_date"];
  $updation_date= $row["blogger_updated_date"];
?>

<div class="both">

<div class="image">

<?php

$con = mysqli_connect("localhost","root","","blog");
if (!$con)
  {
  die('Could not connect: ' . mysqli_error());
  }
  
  $image_query= "SELECT is_image_uploaded FROM blogger_info WHERE blogger_username='$username'";
  $image_result=mysqli_query($con,$image_query);
  $image_row = mysqli_fetch_assoc($image_result);
  $confirm_image=$image_row['is_image_uploaded'];
  if($confirm_image==1)
  {
	  $get_image_query="SELECT blogger_image FROM blogger_info WHERE blogger_username='$username'";
	  $get_image_result=mysqli_query($con,$get_image_query);
	  $get_image_row = mysqli_fetch_assoc($get_image_result);
	  $sImage= $get_image_row['blogger_image'];
	  echo '<img style="width:100%; height:100%;" src="' . $sImage . ' " alt="Your Image"/>';
	  echo'<form name="myForm" enctype="multipart/form-data" onsubmit="" action="" method="post" class="display">';
	  echo'<input type="submit"value="Change Pic" name="ChangeImage" style="float:right;"/>';
		echo'</form>';
		if(isset($_POST['ChangeImage'])){
			$change_image_query= "UPDATE blogger_info SET is_image_uploaded='0' WHERE blogger_username='$username'";
			$change_image_result=mysqli_query($con,$change_image_query);
			$confirm_image=0;
		}
		
  }
  if($confirm_image==0){
  
echo'<form name="myForm" enctype="multipart/form-data" onsubmit="" action="" method="post" class="display">';
		echo'<input type="hidden" name="submitted" value="true" />';
		
		echo'<input type= "file" name="image">';
		echo'<br>';
		echo'<input type="submit"value="Upload Profile Pic" name="UploadImage"/>';
		echo'</form>';
		
		if(isset($_POST['UploadImage'])){
			$aExtraInfo = getimagesize($_FILES['image']['tmp_name']);
			$sImage = "data:" . $aExtraInfo["mime"] . ";base64," . base64_encode(file_get_contents($_FILES['image']['tmp_name']));	
			$upload_image_query= "UPDATE blogger_info SET is_image_uploaded='1' , blogger_image='$sImage' where blogger_username='$username'";
			$upload_image_result=mysqli_query($con,$upload_image_query);
			header("location:myInfo.php");
		}
  }
 
		mysqli_close($con);
		?>

</div>
<div class="table">

<table class= "design">
	<tr>
		<th>ID</th>
		<td><?php echo $id;?></td>
	</tr>
	
	<tr>
		<th>Username</th>
		<td><?php echo $name;?></td>
	</tr>
	
	<tr>
		<th>Email</th>
		<td><?php echo $email;?></td>
	</tr>
	
	<tr>
		<th>Account Created On</th>
		<td><?php echo $creation_date;?></td>
	</tr>
	
	<tr>
		<th>Account Updated On</th>
		<td><?php echo $updation_date;?></td>
	</tr>
</table>
</div>
<br>
<a href="edit_profile.php" style="margin-left:740px; font-size:20px; color:red;"><b>Edit your Profile</b></a>


</div>
</body>
</html>