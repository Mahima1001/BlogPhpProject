<?php 
session_start();
if(!isset($_SESSION['username'])){
	header("location:mainpage.php");
	exit();
}
?>

<html>
<head>

 <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	
	
<style>
	body{
	background : url(images/background.jpg);
	background-size: 100% 100%;
	background-attachment: fixed;
}
	
	#header{
		text-align:center;
		color: darkbrown;
		 font: 85% Arial, Sans-Serif;
		 font-size:40px;
		 font-weight:bold;
	}
	
	#preheader{
		float:right;
		margin-right:10px;
		margin-top:30px;
		
	}
	
	#footer{
		font-size:20px;
		list-style:none;
		color:#663500;
		margin-top:20px;
		width:15%;
		float:left;
		margin-left:7%;
		position:fixed;
		
	}
	#footerli{
		color:#663500;
		margin-bottom:25px;
	
	}
	#footer li a{
		text-decoration:none;
		color:white;
		font-weight:bold;
		font-size:20px;
		list-style:none;
		
	}
	
	#footer ul{
		list-style:none;
	}
	#center{
		width:100%;
		height:100%;
	}
	
	#centerright{
		width:75%;
		height:100%;
		float:right;
		margin-right:10%;
	}
	
	.sub3{
			float:right;
			width:750px;
			height:100%;
			
		}
		
		.blogtitle{
			height:7%;
			padding:5px;
			font-weight:bold;
			font-size:20px;
			background-color:#8B4513;
			color:red;
		}
		
		.blogdesc{
			height:30%;
			padding:5px;
			background-color:#CD853F;
			color:white;
		}
		
		.image{
			height:58%;
			width:100%;
			position:relative;
			}
		
		.imagesize{
		max-width:100%;
		max-height:100%;
	}	
	
	h2{
		position: absolute; 
   top: 20px; 
   left: 0; 
   width: 100%; 
	}
	
	h2 span { 
   color: white; 
   font: bold  Helvetica, Sans-Serif; 
   letter-spacing: -1px;  
   background: rgb(0, 0, 0); /* fallback color */
   background: rgba(0, 0, 0, 0.7);
   padding: 10px; 
}

	h3{
		position: absolute; 
   top: 220px; 
   right: 0; 
   width: 100%; 
	}
	
	h4{
		position: absolute; 
   top: 270px; 
   right: 0; 
   float:right;
   width: 100%;
	font-size:5px;
	}
	
	h3 span { 
   color: white; 
   font:  Helvetica, Sans-Serif; 
   letter-spacing: -1px;  
   background: rgb(0, 0, 0); /* fallback color */
   background: rgba(0, 0, 0, 0.7);
   padding: 10px; 
   float:right;
   font-size:18px;
}

h4 span { 
   color: white; 
   font:  Helvetica, Sans-Serif; 
   letter-spacing: -1px;  
   background: rgb(0, 0, 0); /* fallback color */
   background: rgba(0, 0, 0, 0.7);
   padding: 2px; 
   float:right;
   font-size:18px;
}

.allowORdeny{
		float:right;
		margin:5px;
	}
	
	.allowblog{
		background-color:#663500;
		color:white;
		padding:2px;
		width:58px;
		height:28px;
	}
</style>
</head>
<body>

<?php
$_SESSION['user']="allow";
?>

<div id ="main">
<div id ="header">
	<p> Articles </p>
</div>
<div id="center">
<p>hi</p>
<div id= "footer">
	<ul>
			<?php 
			$nameofuser= $_SESSION['username'];
			$con = mysqli_connect("localhost","root","","blog");
			if (!$con)
			{
				die('Could not connect: ' . mysqli_error());
			}
			$query= "SELECT admin FROM blogger_info WHERE blogger_username='$nameofuser'";
			$result=mysqli_query($con,$query);
			$row = mysqli_fetch_assoc($result);
			if($row['admin']==1)
			{
				echo'<li id= "footerli"><a href="admin.php"><span class="glyphicon glyphicon-home" style= "color:#ff0000"></span>Home</a></li>';
			}
			else
			{
				echo'<li id= "footerli"><a href="welcome.php"><span class="glyphicon glyphicon-home" style= "color:#ff0000"></span>Home</a></li>';
			}
			?>
		  <li id= "footerli"><a href="addblog.php"><span class="glyphicon glyphicon-plus" style= "color:#ff0000"></span>Add Article</a></li>
		  <li id= "footerli"><a href="logout.php"><span class="glyphicon glyphicon-off" style= "color:#ff0000"></span>LogOut</a></li>
        </ul>
</div>
<div id="centerright">
<?php

$conn = mysqli_connect("localhost","root","","blog");
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$username= $_SESSION['username'];
$sql = "SELECT blog_id,blog_title,blogger_id,blog_desc,blog_category, blog_author,blog_day,updated_date FROM blog_master";
$result=mysqli_query($conn,$sql);


if (mysqli_num_rows($result) > 0) {
    while($row = mysqli_fetch_assoc($result)) {
		
		$bloggerid= $row['blogger_id'];
		$query= "SELECT blogger_username FROM blogger_info WHERE blogger_id='$bloggerid'";
		$result2=mysqli_query($conn,$query);
		$row2 = mysqli_fetch_assoc($result2);
		
echo '<div class="sub3">';
				echo '<div class="image">';
				$blogid= $row["blog_id"];
				$image_query= "SELECT blog_detail_image FROM blog_detail where blog_id='$blogid'";
				$image_result=mysqli_query($conn,$image_query);
				$image_row = mysqli_fetch_assoc($image_result);
				echo '<img style="width:100%; height:100%;" src="' . $image_row["blog_detail_image"] . ' " alt="Your Image"/>';
						echo '<h2><span>'.$row["blog_category"].'</span></h2>';
							echo '<h3><span>'.$row["blog_author"].'</span></h3>';
							echo '<h4><span>'.$row["updated_date"].' '.$row["blog_day"].'</span></h4>';
					echo "</div>";
				echo '<div class="blogtitle">';
					echo $row["blog_title"];
				echo "</div>";
				echo '<div class="blogdesc">';
					echo $row["blog_desc"];
				echo "</div>";
					echo '<p style=" margin-right:0px; margin-left:550px; font-size:20px;">Posted by : <a href="BloggerDetail.php? id='.$row['blogger_id'].'" style="color:red; font-weight:bolder;">'.$row2['blogger_username'].'</a></p>';

		echo "<br>";
		echo "<br>";
		echo "<br>";
	}
	echo "</div>";
}
		
		?>

</div>
</div>
</div>
</body>
</html>
