<?php
session_start();
?>
<html>
<body>
<?php
$id = $_POST['blogid'];

$con = mysqli_connect("localhost","root","","blog");
if (!$con)
  {
  die('Could not connect: ' . mysqli_error());
  }
//mysql_select_db("blog", $con);

  $delete_query="DELETE FROM temp_table where blog_id='$id'";
  $delete_result=mysqli_query($con,$delete_query);
  
  $query="DELETE FROM check_blog where blog_id='$id'";
  $result=mysqli_query($con,$query);
  
  
  $num=mysqli_num_rows($result);
  if($num > 0)
  {
	  $_SESSION["deleted"]="not deleted successfully";
	  header("Location:admin.php");
  }
  else{
		$_SESSION["deleted"]="deleted successfully";
	  header("Location:admin.php");
  }
 
mysqli_close($con);
?>
</body>
</html>