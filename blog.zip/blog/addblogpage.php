<?php
session_start();
?>

<html>
<head>
<style>
body{
	background : url(images/background.jpg);
	background-size: 100% 100%;
}
.error{
			color:red;
		}
		body{
			background-repeat:no-repeat;
			background-size:100%;
			background-attachment:fixed;
		}
		.sub2{
			background-color:#663500;
			color:white;
			padding:20px;
			padding-right:50px;
			padding-left:50px;
			width:25%;
			border-width:5px;
			border-color:white;
			float:left;
			border-width:5px;
			height:80%;
		}
		#sub1{
			
			color:#663500;
			margin-top:50px;
			
		}
		.inputclass{
			width:180px;
			margin:auto;
			height:34px;
			border-radius:5px;
		}
		
		.sub3{
			float:right;
			width:50%;
			margin-right:10%;
			height:100%;
			background-color:red;
		}
		.sub4{
			width:100%;
			height:90%;
			background-color:black;
		}
		.blogcategory{
			width:40%;
			height:5%;
			opacity: 0.5;
			filter: alpha(opacity=50);
			float:left;
			padding:5px;
			margin-top:3%;
			background-color:white;
			position:absolute;
			z-index: 1000;
		}
		
		.blogtitle{
			height:7%;
			background-color:green;
			padding:5px;
		}
		
		.blogdesc{
			height:30%;
			background-color:yellow;
			padding:5px;
		}
		
		.blogauthor{
			width:100%;
			height:30%;
			float:right;
			
			
		}
		
		.blogdate{
			width:100%;
			height:30%;
			float:right;
			margin-top:5%;
			
			
		}
		.image{
			height:58%;
			width:100%;
			background-color:darkgreen;
			position:relative;
			}
		
		.authoranddate{
			width:26%;
			height:8%;
			float:right;
			margin-top:45%;
			
		}
		
		.descclass{
			width:240px;
			height:120px;
			border-radius:5px;
		}
		
	.verifyblog{
		float:right;
		background-color:red;
		color:white;
		font-weight:bold;
		margin-right:12%;
	}
	
	.imagesize{
		max-width:100%;
		max-height:100%;
	}	
	

</style>

</head>
<body>

<H1 align="center" id="sub1" style="color: darkbrown"><B><U>Blog Information</B></U></H1>
		<p id="sub1"><b>The field with ' <span style = "color:#ff0000">*</span> ' mark is required</b></p>
		<form name="myForm" enctype="multipart/form-data" onsubmit="" action="" method="post">
		<input type="hidden" name="submitted" value="true" />
			<div class= "sub4">
			<div class="sub2" >
			
				<table>
					<tr>
						<td>Title<span class="error">*</span></td>
						<td><input type="text" class="inputclass" name="blogtitle" id="B" value='' onFocus="this.value=''" required/></td>
					</tr>
					<tr></tr>
					<tr></tr>
					<tr></tr>
					<tr></tr>
					<tr></tr>
					<tr></tr>
					<tr></tr>
					
					
				
					
					<tr>
						<td>Category<span class="error">*</span> </td>
						<td> <input type="text" name="blogcategory" class="inputclass" required/></td>
					</tr>
					<tr></tr>
					<tr></tr>
					<tr></tr>
					<tr></tr>
					<tr></tr>
					<tr></tr>
					<tr></tr>
					
					
					<tr>
						<td>Author<span class="error">*</span> </td>
						<td><input type="text" name="blogauthor" class="inputclass" required/> </td>
					</tr>
					<tr></tr>
					<tr></tr>
					<tr></tr>
					<tr></tr>
					<tr></tr>
					<tr></tr>
					<tr></tr>
					
					<tr>	
						<td>Description<span class="error">*</span> </td>
						<td> <textarea class="descclass"  name="blogdesc" rows=7 cols=50  id="C" required/></textarea></td>
					</tr>
					<tr></tr>
					<tr></tr>
					<tr></tr>
					<tr></tr>
					<tr></tr>
					<tr></tr>
					<tr></tr>
					<tr><td></td>
					<td>
					<input type= "file" name="image" required/>
					
					</tr>
					<tr></tr>
					<tr></tr>
					<tr></tr>
					<tr></tr>
					<tr></tr>
					<tr></tr>
					<tr></tr>
					<tr></tr>
					<tr></tr>
					<tr></tr>
					<tr></tr>
					<tr></tr>
					<tr></tr>
					<tr></tr>
					<tr></tr>
					<tr>
						<td><input type="submit"value="Display Blog" name="Displayblog"/></td>
						<td><input type="reset" value="Reset" /></td>
					</tr>
					
					
				</table>
				</form>
				</div>;
				<?php
				if (isset($_POST['Displayblog'])) {
				
			
			echo '<div class="sub3">';
				echo '<div class="image">';
				 

					echo '<div class="blogcategory">';
						echo $_POST['blogcategory'];
					echo "</div>";
					echo'<div class= "authoranddate">';
						echo '<div class="blogauthor">';
							echo "By-> ".$_POST['blogauthor'];
						echo "</div>";
						echo '<div class="blogdate">';
							echo date("Y/m/d")." ".date("l");
						echo "</div>";
					echo "</div>";
				$aExtraInfo = getimagesize($_FILES['image']['tmp_name']);
				$sImage = "data:" . $aExtraInfo["mime"] . ";base64," . base64_encode(file_get_contents($_FILES['image']['tmp_name']));
				echo '<img style="width:100%; height:100%;" src="' . $sImage . ' " alt="Your Image"/>';
				echo "</div>";
				echo '<div class="blogtitle">';
					echo $_POST['blogtitle'];
				echo "</div>";
				echo '<div class="blogdesc">';
					echo $_POST['blogdesc'];
				echo "</div>";
			echo "</div>";
			echo "</div> ";
			echo '<form name="myForm2" enctype="multipart/form-data" onsubmit="" action="" method="post">';
		echo '<input class="verifyblog" type="submit"value="Verify Blog" name="Verifyblog"/>';
		echo "</form>";
			
				}
	?>
	
	
		
		
</body>
</html>