<?php
session_start();
?>

<?php
$con = mysqli_connect("localhost","root","","blog");
if (!$con)
  {
  die('Could not connect: ' . mysqli_error());
  }
//mysql_select_db("blog", $con);
 
  $name=$_POST['username'];
  $pwd=$_POST['password'];
  
  
  $query="SELECT blogger_username, blogger_password FROM blogger_info where blogger_username='$name' and blogger_password='$pwd' and blogger_is_active=1";
  $result=mysqli_query($con,$query);
  $num=mysqli_num_rows($result);
  
  $query_admin="SELECT blogger_username FROM blogger_info where admin = 1";
  $result_admin=mysqli_query($con,$query_admin);
  $row_admin = mysqli_fetch_assoc($result_admin);
  $admin= $row_admin['blogger_username'];
  
  if($num > 0)
  {
	  if(strcmp($name,$admin)==0){
		  $_SESSION['username']=$name;
		  header("Location:admin.php");
	  }
	  else{
		  $_SESSION['username']=$name;
	  header("Location:welcome.php");
	  }
  }
  else
  {
			 $_SESSION['login']="login failed";
	  	  header("Location:mainpage.php");
} 
  
mysqli_close($con);
?>
