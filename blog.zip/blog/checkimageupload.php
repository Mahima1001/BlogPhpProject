<!DOCTYPE html>
<html>
<head>
    <title>Insert Image</title>
</head>
<body>
<?php
$msg = '';
if($_SERVER['REQUEST_METHOD']=='POST'){
	if(isset($_POST['summit'])){
    $image = $_FILES['image']['tmp_name'];
    $img = file_get_contents($image);
    $con = mysqli_connect('localhost','root','','blog') or die('Unable To connect');
    $sql = "insert into blog_detail (blog_detail_image) values(?)";

    $stmt = mysqli_prepare($con,$sql);

    mysqli_stmt_bind_param($stmt, "s",$img);
    mysqli_stmt_execute($stmt);

    $check = mysqli_stmt_affected_rows($stmt);
	echo $check;
    if($check==1){
        $msg = 'Successfullly UPloaded';
    }else{
        $msg = 'Could not upload';
    }
    mysqli_close($con);
}
}
?>
<form action="checkimageupload.php" method="post" enctype="multipart/form-data">
    <input type="file" name="image" />
    <input type="submit" name="summit">Upload</button>
</form>
<?php
    echo $msg;
?>
</body>
</html>