<?php
session_start();
?>
<html>
<body>
<?php
$con = mysqli_connect("localhost","root","","blog");
if (!$con)
  {
  die('Could not connect: ' . mysqli_error());
  }
//mysql_select_db("blog", $con);
 $image= $_POST['image'];
  $sqlinsert="INSERT INTO blog_detail(blog_detail_image) VALUES ('$image')";
  if(!mysqli_query($con,$sqlinsert)){
	 die('error inserting new record') ;
	  
  }else
  
  {
	 echo "yeah";
} 
mysqli_close($con)
?>

</body>
</html>
