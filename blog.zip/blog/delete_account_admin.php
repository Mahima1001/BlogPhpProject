<?php
session_start();
?>
<html>
<body>
<?php

$bloggerid=$_POST['blogid'];
$con = mysqli_connect("localhost","root","","blog");
if (!$con)
  {
  die('Could not connect: ' . mysqli_error());
  }

  $query="UPDATE blogger_info SET blogger_is_active='0', blogger_end_date=CURDATE() WHERE blogger_id='$bloggerid'";
  if(!mysqli_query($con,$query)){
	 die('error inserting new record') ;
	  
  }else
  
  {
	  header("location:viewbloggers.php");
}
 
mysqli_close($con);
?>

</body>
</html>
