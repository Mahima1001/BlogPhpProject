<?php
session_start();
?>
<html>
<body>
<?php
$con = mysqli_connect("localhost","root","","blog");
if (!$con)
  {
  die('Could not connect: ' . mysqli_error());
  }
  
  $query_admin="SELECT blogger_username FROM blogger_info where admin = 1";
  $result_admin=mysqli_query($con,$query_admin);
  $row_admin = mysqli_fetch_assoc($result_admin);
  $admin= $row_admin['blogger_username'];
  
  $name= $_SESSION['blog_username_edit'];
  $category=$_SESSION['blog_category_edit'];
  $title=$_SESSION['blog_title_edit'];
  $desc=$_SESSION['blog_desc_edit'];
  $author=$_SESSION['blog_author_edit'];
  $day= $_SESSION['blog_day_edit'];
  $image=$_SESSION['image_edit'];
  $old_title=$_SESSION['old_title'];
  $sqlinsert="INSERT INTO check_blog(blogger_name,blog_category,blog_title,blog_desc,blog_author,blog_date,blog_day,blog_image,updated,old_title) VALUES ('$name','$category','$title','$desc','$author',CURDATE(),'$day','$image',1,'$old_title')";
  if(!mysqli_query($con,$sqlinsert)){
	 die('error inserting new record') ;
	  
  }else
  
  {
	  if(strcmp($_SESSION['username'],$admin)==0)
	  {
	  header("location:admin.php");
	  }
	  else{
		  header("location:welcome.php");
	  }
}
 
mysqli_close($con);
?>

</body>
</html>
