<?php
session_start();
?>
<html>
<title>Blogger's point</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<head>

<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<style type="text/css" media="all">
body { margin:5px 0; padding:0; font: 74% Arial, Sans-Serif; color:#000; line-height: 1.4em; background : url(images/background.jpg);
	background-size: 100% 100%;
	background-attachment: fixed;}
.content { color: #3B2A0A; margin: 0 auto; padding: 0; }
#header {color: #3B2A0A; background : url(images/subbgimage.jpg); }
#header h1 {  font: bold 3em "Tahoma", Arial; color: brown; float:left; margin-left:10px;}
#header h3 {  font: bold 1em "Tahoma", Arial; color: #000; float:left; margin-left:10px; margin-top:-130px;}
#header .title { padding-top:10px;}

/*LOGIN BUTTON*/
#loginme{
	margin-left:700px;
	margin-top:-30px;
	color:#8f8f8f;
	padding:5px;
	margin-bottom:10px;
	height:200px;
	
}


/*-------------------------for SignIn page------------------------------*/


 .login-submit, .login-submit:before, .login-submit:after {
  background: #373737 url("../img/bg.png") 0 0 repeat;
  line-height:1;
}

a {
  color: #00a1d2;
  text-decoration: none;
}
a:hover {
  text-decoration: underline;
}

.login {
  position: relative;
  margin: 80px auto;
  width: 300px;
  padding-right: 32px;
  font-weight: 300;
  color: #a8a7a8;
  text-shadow: 1px 1px 0 rgba(0, 0, 0, 0.8);
}
.login p {
  margin: 0 0 10px;
}

input, button, label {
  font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif;
  font-size: 15px;
  font-weight: 300;
  -webkit-box-sizing: border-box;
  -moz-box-sizing: border-box;
  box-sizing: border-box;
}

input[type=text], input[type=password] {
  padding: 0 10px;
  width: 200px;
  height: 40px;
  color: #bbb;
  text-shadow: 1px 1px 1px black;
  background: rgba(0, 0, 0, 0.16);
  border: 0;
  border-radius: 5px;
  -webkit-box-shadow: inset 0 1px 4px rgba(0, 0, 0, 0.3), 0 1px rgba(255, 255, 255, 0.06);
  box-shadow: inset 0 1px 4px rgba(0, 0, 0, 0.3), 0 1px rgba(255, 255, 255, 0.06);
}
input[type=text]:focus, input[type=password]:focus {
  color: white;
  background: rgba(0, 0, 0, 0.1);
  outline: 0;
}

label {
  float: left;
  width: 100px;
  line-height: 40px;
  padding-right: 10px;
  font-weight: 100;
  text-align: right;
  letter-spacing: 1px;
}

.login-submit {
  position: absolute;
  top: 12px;
  right: 0;
  width: 48px;
  height: 48px;
  padding: 8px;
  border-radius: 32px;
  -webkit-box-shadow: 0 0 4px rgba(0, 0, 0, 0.35);
  box-shadow: 0 0 4px rgba(0, 0, 0, 0.35);
}
.login-submit:before, .login-submit:after {
  content: '';
  z-index: 1;
  position: absolute;
}
.login-submit:before {
  top: 28px;
  left: -4px;
  width: 4px;
  height: 10px;
  -webkit-box-shadow: inset 0 1px rgba(255, 255, 255, 0.06);
  box-shadow: inset 0 1px rgba(255, 255, 255, 0.06);
}
.login-submit:after {
  top: -4px;
  bottom: -4px;
  right: -4px;
  width: 36px;
}

.login-button {
  position: relative;
  z-index: 2;
  width: 48px;
  height: 48px;
  padding: 0 0 48px;
  /* Fix wrong positioning in Firefox 9 & older (bug 450418) */
  text-indent: 120%;
  white-space: nowrap;
  overflow: hidden;
  background: none;
  border: 0;
  border-radius: 24px;
  cursor: pointer;
  -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.2), 0 1px rgba(255, 255, 255, 0.1);
  box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.2), 0 1px rgba(255, 255, 255, 0.1);
  /* Must use another pseudo element for the gradient background because Webkit */
  /* clips the background incorrectly inside elements with a border-radius.     */
}
.login-button:before {
  content: '';
  position: absolute;
  top: 5px;
  bottom: 5px;
  left: 5px;
  right: 5px;
  background: #00a2d3;
  border-radius: 24px;
  background-image: -webkit-linear-gradient(top, #00a2d3, #0d7796);
  background-image: -moz-linear-gradient(top, #00a2d3, #0d7796);
  background-image: -o-linear-gradient(top, #00a2d3, #0d7796);
  background-image: linear-gradient(to bottom, #00a2d3, #0d7796);
  -webkit-box-shadow: inset 0 0 0 1px #00a2d3, 0 0 0 5px rgba(0, 0, 0, 0.16);
  box-shadow: inset 0 0 0 1px #00a2d3, 0 0 0 5px rgba(0, 0, 0, 0.16);
}
.login-button:active:before {
  background: #0591ba;
  background-image: -webkit-linear-gradient(top, #0591ba, #00a2d3);
  background-image: -moz-linear-gradient(top, #0591ba, #00a2d3);
  background-image: -o-linear-gradient(top, #0591ba, #00a2d3);
  background-image: linear-gradient(to bottom, #0591ba, #00a2d3);
}
.login-button:after {
  content: '';
  position: absolute;
  top: 15px;
  left: 12px;
  width: 25px;
  height: 19px;
  background: url("../img/arrow.png") 0 0 no-repeat;
}

::-moz-focus-inner {
  border: 0;
  padding: 0;
}

.lt-ie9 input[type=text], .lt-ie9 input[type=password] {
  line-height: 40px;
  background: #282828;
}
.lt-ie9 .login-submit {
  position: absolute;
  top: 12px;
  right: -28px;
  padding: 4px;
}
.lt-ie9 .login-submit:before, .lt-ie9 .login-submit:after {
  display: none;
}
.lt-ie9 .login-button {
  line-height: 48px;
}
.lt-ie9 .about {
  background: #313131;
}

.forgot-password {
  padding-left: 100px;
  font-size: 12px;
  font-weight: 100;
  letter-spacing: 1px;
}


.sub3{
			float:right;
			width:750px;
			height:100%;
			
		}
		
		.blogtitle{
			height:7%;
			padding:5px;
			font-weight:bold;
			font-size:20px;
			background-color:#8B4513;
			color:red;
		}
		
		.blogdesc{
			height:30%;
			padding:5px;
			background-color:#CD853F;
			color:white;
		}
		
		.image{
			height:58%;
			width:100%;
			position:relative;
			}
		
		.imagesize{
		max-width:100%;
		max-height:100%;
	}	
	
	h2{
		position: absolute; 
   top: 20px; 
   left: 0; 
   width: 100%; 
	}
	
	h2 span { 
   color: white; 
   font: bold  Helvetica, Sans-Serif; 
   letter-spacing: -1px;  
   background: rgb(0, 0, 0); /* fallback color */
   background: rgba(0, 0, 0, 0.7);
   padding: 10px; 
}

	h3{
		position: absolute; 
   top: 220px; 
   right: 0; 
   width: 100%; 
	}
	
	h4{
		position: absolute; 
   top: 270px; 
   right: 0; 
   float:right;
   width: 100%;
	font-size:5px;
	}
	
	h3 span { 
   color: white; 
   font:  Helvetica, Sans-Serif; 
   letter-spacing: -1px;  
   background: rgb(0, 0, 0); /* fallback color */
   background: rgba(0, 0, 0, 0.7);
   padding: 10px; 
   float:right;
   font-size:18px;
}

h4 span { 
   color: white; 
   font:  Helvetica, Sans-Serif; 
   letter-spacing: -1px;  
   background: rgb(0, 0, 0); /* fallback color */
   background: rgba(0, 0, 0, 0.7);
   padding: 2px; 
   float:right;
   font-size:18px;
}

#footer{
		font-size:20px;
		list-style:none;
		color:#663500;
		margin-top:20px;
		width:15%;
		float:left;
		margin-left:7%;
		position:fixed;
		
	}
	#footerli{
		color:#663500;
		margin-bottom:25px;
	
	}
	#footer li a{
		text-decoration:none;
		color:white;
		font-weight:bold;
		font-size:20px;
		list-style:none;
		
	}
	
	#footer ul{
		list-style:none;
	}
	#center{
		width:100%;
		height:100%;
	}
	
	#centerright{
		width:75%;
		height:100%;
		float:right;
		margin-right:10%;
	}
	

</style>
</head>
<body>

<a href="mainpage.php"><span class="glyphicon glyphicon-arrow-left" style= "color:black; font-size:35px;"></span></a>
<div id="centerright">
<?php

$conn = mysqli_connect("localhost","root","","blog");
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

//$username= $_SESSION['username'];
$sql = "SELECT blog_id,blog_title,blogger_id,blog_desc,blog_category, blog_author,blog_day,updated_date FROM blog_master";
$result=mysqli_query($conn,$sql);


if (mysqli_num_rows($result) > 0) {
    while($row = mysqli_fetch_assoc($result)) {
		
		$bloggerid= $row['blogger_id'];
		$query= "SELECT blogger_username FROM blogger_info WHERE blogger_id='$bloggerid'";
		$result2=mysqli_query($conn,$query);
		$row2 = mysqli_fetch_assoc($result2);
		
echo '<div class="sub3">';
				echo '<div class="image">';
				$blogid= $row["blog_id"];
				$image_query= "SELECT blog_detail_image FROM blog_detail where blog_id='$blogid'";
				$image_result=mysqli_query($conn,$image_query);
				$image_row = mysqli_fetch_assoc($image_result);
				echo '<img style="width:100%; height:100%;" src="' . $image_row["blog_detail_image"] . ' " alt="Your Image"/>';
						echo '<h2><span>'.$row["blog_category"].'</span></h2>';
							echo '<h3><span>'.$row["blog_author"].'</span></h3>';
							echo '<h4><span>'.$row["updated_date"].' '.$row["blog_day"].'</span></h4>';
					echo "</div>";
				echo '<div class="blogtitle">';
					echo $row["blog_title"];
				echo "</div>";
				echo '<div class="blogdesc">';
					echo $row["blog_desc"];
				echo "</div>";
					echo '<p style=" margin-top:5px;margin-right:0px; margin-left:550px; font-size:20px;">Posted by : <a href="BloggerDetail.php? id='.$row['blogger_id'].'" style="color:red; font-weight:bolder;">'.$row2['blogger_username'].'</a></p>';

		echo "<br>";
		echo "<br>";
		echo "<br>";
	}
	echo "</div>";
}
		
		?>

</div>
</body>
</html>
