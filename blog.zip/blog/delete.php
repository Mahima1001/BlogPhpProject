<?php
session_start();
?>
<html>
<body>
<?php
$id = $_POST['blogid'];

$con = mysqli_connect("localhost","root","","blog");
if (!$con)
  {
  die('Could not connect: ' . mysqli_error());
  }
//mysql_select_db("blog", $con);


 $query="DELETE FROM blog_detail where blog_id='$id'";
  $result=mysqli_query($con,$query);                        //----------------delete this first since blog_id is a foreign key attribute
  
  
  $delete_query="DELETE FROM blog_master where blog_id='$id'";
  $delete_result=mysqli_query($con,$delete_query);
  
 $query_admin="SELECT blogger_username FROM blogger_info where admin = 1";
  $result_admin=mysqli_query($con,$query_admin);
  $row_admin = mysqli_fetch_assoc($result_admin);
  $admin= $row_admin['blogger_username'];
  
  
  $num=mysqli_num_rows($delete_result);
  if($num > 0)
  {
	  $_SESSION["deletedblog"]="not deleted successfully";
	  if(strcmp($_SESSION['username'],$admin)==0)
	  {
	  header("Location:admin.php");
	  }
	  else{
		  header("Location:welcome.php");
	  }
  }
  else{
		$_SESSION["deletedblog"]="deleted successfully";
		if(strcmp($_SESSION['username'],$admin)==0)
	  {
	  header("Location:admin.php");
	   }
	   else{
		  header("Location:welcome.php");
	  }
  }
	   
 
mysqli_close($con);
?>
</body>
</html>