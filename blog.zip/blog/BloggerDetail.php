<?php
session_start();
?>
<html>
<head>
<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<style>
body{
	background : url(images/background.jpg);
	background-size: 100% 100%;
	background-attachment: fixed;
}

.design{
	border: 5px solid black;
	margin:auto;
	
}

tr, th, td{
	border: 2px solid black;
	 padding: 15px;
	 font-size:25px;
	 text-align:center;
	 margin-left:10px;
	 margin-right:10px;
}

.both{
	margin:auto;
	text-align:center;
}

.image{
	width:200px;
	height:230px;
	float:left;
	margin-left:200px;
}

.table{
	float:right;
	width:650px;
	margin-right:200px;
}
.design2{
	border: 5px solid black;
}

</style>
</head>

<body>
<?php



if(strcmp($_SESSION['viewer'],"hi")==0)
{
	echo'<a href="viewerpage.php"><span class="glyphicon glyphicon-arrow-left" style= "color:black; font-size:35px;"></span></a>';
}
else{
$nameofuser= $_SESSION['username'];
$con = mysqli_connect("localhost","root","","blog");
if (!$con)
  {
  die('Could not connect: ' . mysqli_error());
  }
  $query= "SELECT admin FROM blogger_info WHERE blogger_username='$nameofuser'";
  $result=mysqli_query($con,$query);
  $row = mysqli_fetch_assoc($result);
  if($row['admin']==1)
  {
	echo'<a href="articles.php"><span class="glyphicon glyphicon-arrow-left" style= "color:black; font-size:35px;"></span></a>';
  }
  else
  {
	  echo'<a href="articles.php"><span class="glyphicon glyphicon-arrow-left" style= "color:black; font-size:35px;"></span></a>';
  }
}
  ?>

<?php

$id= $_GET['id'];
$con = mysqli_connect("localhost","root","","blog");
if (!$con)
  {
  die('Could not connect: ' . mysqli_error());
  }
  
  $query = "SELECT blogger_id ,blogger_is_active, blogger_username , blogger_email , blogger_creation_date , blogger_updated_date,blogger_image,is_image_uploaded FROM blogger_info where blogger_id= '$id'";
  $result=mysqli_query($con,$query);
  $row = mysqli_fetch_assoc($result);
  $id= $row["blogger_id"];
  $name= $row["blogger_username"];
  $email= $row['blogger_email'];
  $creation_date= $row["blogger_creation_date"];
  $updation_date= $row["blogger_updated_date"];
  $is_image_uploaded=$row["is_image_uploaded"];
  $blogger_active= $row["blogger_is_active"];
  $blogger_image= $row["blogger_image"];
  
  if($is_image_uploaded==0){


	echo'<table class= "design">';
	echo'<tr>';
		echo'<th>'; echo'ID'; echo'</th>';
		echo'<td>'.$id.'</td>';
	echo'</tr>';
	
	echo'<tr>';
		echo'<th>';echo'Username';echo'</th>';
		echo'<td>'.$name.'</td>';
	echo'</tr>';
	
	echo'<tr>';
		echo'<th>';echo'Email';echo'</th>';
		echo'<td>';echo'<a href="mailto:<?php echo $email;?>?Subject=Hello" target="_top">Send Mail</a>';echo'</td>';
	echo'</tr>';
	
	echo'<tr>';
		echo'<th>Account Created On</th>';
		echo'<td>'.$creation_date.'</td>';
	echo'</tr>';
	
	echo'<tr>';
		echo'<th>Account Updated On</th>';
		echo'<td>'.$updation_date.'</td>';
	echo'</tr>';
echo'</table>';
  }
  
  if($is_image_uploaded==1){
	  echo'<div class="both">';

echo'<div class="image">';

 echo '<img style="width:100%; height:100%;" src="' . $blogger_image . ' " alt="Your Image"/>';
	 echo'</div>';
	 echo'<div class="table">';
	 echo'<table class= "design2">';
	echo'<tr>';
		echo'<th>'; echo'ID'; echo'</th>';
		echo'<td>'.$id.'</td>';
	echo'</tr>';
	
	echo'<tr>';
		echo'<th>';echo'Username';echo'</th>';
		echo'<td>'.$name.'</td>';
	echo'</tr>';
	
	echo'<tr>';
		echo'<th>';echo'Email';echo'</th>';
		echo'<td>';echo'<a href="mailto:<?php echo $email;?>?Subject=Hello" target="_top">Send Mail</a>';echo'</td>';
	echo'</tr>';
	
	echo'<tr>';
		echo'<th>Account Created On</th>';
		echo'<td>'.$creation_date.'</td>';
	echo'</tr>';
	
	echo'<tr>';
		echo'<th>Account Updated On</th>';
		echo'<td>'.$updation_date.'</td>';
	echo'</tr>';
echo'</table>';
echo'</div>';
echo'</div>';
  }
	
?>
<br>
</body>
</html>