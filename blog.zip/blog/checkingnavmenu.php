	<html>
	<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<style>
	
	body{
		overflow-y: scroll;
		padding :0;
		margin:0;
		font-family:Arial;
		font-size:16px;
		background-color:#F1F1F1;
		height:2000px;
	}
	
	#nav{
		background-color:#222;
		position:fixed;
		width:100%;
		top : 0;
	}
	
	#nav-wrapper{
		width:960px;
		margin: 0 auto;
		text-align:left;
	}
	
	#nav ul{
		list-style-type:none;
		padding:0;
		margin:0;
	}
	
	#nav ul li{
		display :inline-block;
	}
	
	#nav ul li:hover{
		background-color:#333;
	}
	
	#nav ul li a,visited{
		display:block;
		padding:15px;
		color:#CCC;
		text-decoration:none;
	}
	
	#wrapper{
		width:960px;
		margin : 0 auto;
		text-align:left;
	}
	
	#content{
		background-color:#FFF;
		border:2px solid #DDD;
		padding:15px;
		margin: 30px 0 0 0;
	}
	
	</style>
	</head>
	<body>
		<div id="nav">
			<div id="nav-wrapper">
			<ul>
				<li><a href="#">Home</a></li>
				<li><a href="#">Articles</a></li>
				<li><a href="#">Add Blog</a></li>
				<li><a href="#">Log Out</a></li>
			</ul>
			</div>
			</div>
			
			<div id="wrapper">
			<div id="content">
			
			</div>
			</div>
	</body>
	</html>