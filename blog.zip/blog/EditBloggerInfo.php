<?php
session_start();
?>
<html>
<body>
<?php
$con = mysqli_connect("localhost","root","","blog");
if (!$con)
  {
  die('Could not connect: ' . mysqli_error());
  }
//mysql_select_db("blog", $con);

	$old_username=$_SESSION['username'];
 
  $name=$_POST['username'];
  $pwd=$_POST['password'];
  $email=$_POST['email'];
  
  $query_admin="SELECT blogger_username FROM blogger_info where admin = 1";
  $result_admin=mysqli_query($con,$query_admin);
  $row_admin = mysqli_fetch_assoc($result_admin);
  $admin= $row_admin['blogger_username'];
  
  if(strcmp($name,$old_username)==0){
	  $query= "UPDATE blogger_info SET blogger_username='$name', blogger_password='$pwd', blogger_email='$email', blogger_updated_date=CURDATE() WHERE blogger_username='$old_username'";
		$result=mysqli_query($con,$query);
		
		if(strcmp($old_username,$admin)==0){
			$_SESSION['edit_status']= "Edited Successfully";
			$_SESSION['username']=$name;
			header("Location:admin.php");
		}
		else{
			$_SESSION["edit_status"]= "Edited Successfully";
			$_SESSION['username']=$name;
			header("Location:welcome.php");
		}
  
  }
  else{
  $query="SELECT blogger_username FROM blogger_info where blogger_username='$name'";
  $result=mysqli_query($con,$query);
  $num=mysqli_num_rows($result);
  if($num > 0)
  {  
	  $_SESSION["edit_status_username"]="Not Edited";
	  header("Location:edit_profile.php");
  }
  else{
   $query= "UPDATE blogger_info SET blogger_username='$name', blogger_password='$pwd', blogger_email='$email', blogger_updated_date=CURDATE() WHERE blogger_username='$old_username'";
	if(!mysqli_query($con,$query)){
	 die('error inserting new record') ;
	  
  }else
  
  {
	 if(strcmp($old_username,$admin)==0){
			$_SESSION['edit_status']= "Edited Successfully";
			$_SESSION['username']=$name;
			header("Location:admin.php");
		}
		else{
			$_SESSION["edit_status"]= "Edited Successfully";
			$_SESSION['username']=$name;
			header("Location:welcome.php");
		}
}
  }
  }
 
mysqli_close($con);
?>

</body>
</html>
