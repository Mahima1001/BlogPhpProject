<?php
session_start();
?>
<html>
<title>Blogger's point</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<style type="text/css" media="all">
@import "images/style.css";

</style>
<body>
<?php
$_SESSION["check"]="Allow";
$_SESSION["deleted"]="Allow";
$_SESSION["deletedblog"]="Allow";
$_SESSION["edit_status"]="Allow";
$_SESSION["edit_status_username"]="Allow";
$_SESSION['blogger_image']="";
$_SESSION['sameemail']="";
$_SESSION['viewer']="hi";
?>

<?php

if(strcmp($_SESSION['login'],"login failed")==0)
{
	?><script>alert("Either username or password is incorrect!");</script><?php
	
}
$_SESSION['login']="";
?>



<div class="content">
  <div id="header">
    <div class="title">
      <h1>Audacity To Write</h1>
      <h3> A practical blog for impractical people</h3>
    </div>
	<div id= loginme>
	<form method="post" action="checklogin.php" class="login">
    <p>
      <label for="login">Username:</label>
      <input type="text" name="username" id="username"  required>
    </p>

    <p>
      <label for="password">Password:</label>
      <input type="password" name="password" id="password" required>
    </p>
    <p class="login-submit">
      <button type="submit" name="login" class="login-button">Login</button>
    </p>
	
    <p class="forgot-password"><a href="signup.php">Yet not registered? <span style= "color:#ff0000">Click here</span></a></p>
	
  </form>
  </div>
  </div>
  
  
  <div id="main">
  
    <div class="center">
      <h2><u>About Us</u></h2><br>
	  <h5 style="font-size:15px;">Since August 2016, <span style ="color:red;">Audacity To Write </span> has been teaching people how to create blogs. 
	  Not bland corporate crap created to fill up a company webpage. Valuable information that attracts attention, drives traffic, and builds your business.

These days, that is called content marketing.
 Audacity To Write founder Mahima Bhootra has been building businesses with online blogger websites since 1998, before anyone used that term.

Audacity started as a simple one-man blog.
 Today we are known as Audacity To Write  a digital commerce company with more than 200,000 unique customers  and we have grown using useful content, smart copywriting, and exceptional products and services.

No advertising. No venture capital. No outbound sales team.

Just $1,000 in seed cash and a whole lot of time and effort spent teaching others how to do online blogging that works.
 Every product we have released was conceived from the practical, real-world needs we see every day in our audience.

Today we are a profitable company with 8 figures in annual revenue that is growing fast.
 But our mission has never changed: We will help you create the kind of audience-focused content that helps you reach your business goals.
 
 <br>
 <br>
 
 <span style="font-weight:bold; color:red;">What can you expect?</span><br><br>

<span style="font-size:20px; color:red;">> </span>It is not (just) about SEO.<br>
<span style="font-size:20px;color:red;">></span>It is not (just) about social media.<br>
<span style="font-size:20px;color:red;">></span>It is not (just) about blogging or email marketing or conversion.<br><br>
Today, it is always a bigger picture. You need to understand all the facets of effective , and we cover the gamut, daily … for free.
</h5>
    </div>
    <div class="leftmenu">
      <div class="nav">
        <ul>
          <li><a href="viewerpage.php">Articles</a></li>
          <li><a href="Contact.php">Contact</a></li>
        </ul>
      </div>
    </div>
  </div>
  <div id="prefooter">
    
  </div>
  <div id="footer">
    <div class="padding"> Copyright &copy; 2016 Audacity To Write | Design: Mahima Bhootra | <a href="#">Contact</a> | <a href="#">CSS</a> and <a href="#">HTML</a> and <a href="#">php</a> | mahimabhootra96@gmail.com | <a href="#">Login</a> </div>
  </div>
</div>


<?php

if(strcmp($_SESSION['login'],"login failed")==0)
{
	?><script>alert("Either username or password is incorrect!");</script><?php
	$_SESSION['login']="";
}
?>



</body>
</html>
