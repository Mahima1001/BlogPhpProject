<?php
session_start();
?>

<html>
<body>
<?php

$name=$_POST['name'];
$email=$_POST['email'];
$number=$_POST['phnno'];
$doubt=$_POST['blogdesc'];

$con = mysqli_connect("localhost","root","","blog");
if (!$con)
  {
  die('Could not connect: ' . mysqli_error());
  }
  
  $query="SELECT email FROM viewer_contact where email='$email'";
  $result=mysqli_query($con,$query);
  $num=mysqli_num_rows($result);
  if($num > 0)
  {
	  
	  $_SESSION["sameemail"]="Same Email";
	  header("Location:Contact.php");
	  
  }
  else{
	  $contact_query="INSERT INTO viewer_contact(name,email,phone,query) VALUES('$name','$email','$number','$doubt')";
	  $contact_result=mysqli_query($con,$contact_query);
	  $_SESSION["sameemail"]="Done";
	  header("Location:Contact.php");
  }
?>

</body>
</html>