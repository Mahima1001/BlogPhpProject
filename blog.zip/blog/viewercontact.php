<?php
session_start();
?>
<head>
<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<style>
body{
	background : url(images/background.jpg);
	background-size: 100% 100%;
	background-attachment: fixed;
}

.design{
	border: 5px solid black;
	margin:auto;
}

table{
	margin:auto;
	margin-top:40px;
	width:900px;
}

tr, th,td{
	border: 2px solid black;
	 padding: 15px;
	 font-size:25px;
	 text-align:center;
	 margin-left:10px;
	 margin-right:10px;
}
</style>
</head>
<html>
<body>
<a href="admin.php"><span class="glyphicon glyphicon-arrow-left" style= "color:black; font-size:35px;"></span></a>
<?php
$con = mysqli_connect("localhost","root","","blog");
if (!$con)
  {
  die('Could not connect: ' . mysqli_error());
  }

  $query= "SELECT * FROM  viewer_contact";
  $result=mysqli_query($con,$query);
  echo"<table>";
  echo'<tr>';
  echo'<th> NAME </th>';
  echo'<th> CONTACT NO </th>';
  echo'<th> QUERY </th>';
  echo'<th> EMAIL ID </th>';
  echo'</tr>';
  while($row = mysqli_fetch_assoc($result))
  {
	  echo '<tr>';
		echo'<td>'.$row['name'].'</td>';
		echo'<td>'.$row['phone'].'</td>';
		echo'<td>'.$row['query'].'</td>';
		echo'<td>';echo'<a href="mailto:'.$row['email'].'?Subject=Hello" target="_top">'.$row['email'].'</a>';echo'</td>';
	  echo'</tr>';
  }
  echo '</table>';

?>


</body>
</html>