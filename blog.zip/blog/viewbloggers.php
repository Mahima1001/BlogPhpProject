<?php
session_start();
?>
<head>
<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<style>
body{
	background : url(images/background.jpg);
	background-size: 100% 100%;
	background-attachment: fixed;
}

.design{
	border: 5px solid black;
	margin:auto;
}

table{
	margin:auto;
	margin-top:40px;
	width:100%;
}

tr, th,td{
	border: 2px solid black;
	 padding: 5px;
	 font-size:20px;
	 text-align:center;
	 margin-left:2px;
	 margin-right:2px;
}

.verifyblog{
		background-color:#663500;
		color:white;
		margin-left:2px;
		font-size:18px;
		
	}
	.left{
		float:left;
	}
	
	.right{
		float:right;
	}
</style>
</head>
<html>
<body>
<a href="admin.php"><span class="glyphicon glyphicon-arrow-left" style= "color:black; font-size:35px;"></span></a>

<?php
$con = mysqli_connect("localhost","root","","blog");
if (!$con)
  {
  die('Could not connect: ' . mysqli_error());
  }

  $query= "SELECT admin, blogger_id,blogger_username,blogger_email,blogger_is_active,blogger_creation_date,is_image_uploaded,blogger_image FROM  blogger_info";
  $result=mysqli_query($con,$query);
  echo"<table>";
  echo'<tr>';
  echo'<th> PROFILE PIC </th>';
  echo'<th> BLOGGER ID</th>';
  echo'<th> NAME </th>';
    echo'<th> IS BLOGGER ACTIVE?</th>';
    echo'<th> CREATION DATE </th>';
	 echo'<th> EMAIL </th>';
	 echo'<th> ACTIVITY TO PERFORM </th>';
	 
  echo'</tr>';
  while($row = mysqli_fetch_assoc($result))
  {
	  echo '<tr>';
	  echo '<td>';
	  if($row['is_image_uploaded']==1){
	  echo'<img style="width:150px; height:150px;" src="' . $row['blogger_image'] . ' " alt="Your Image"/>';
	  }
	  else{
		  echo'Profile Pic not available';
	  }
	  echo'</td>';
		echo'<td>'.$row['blogger_id'].'</td>';
		echo'<td>'.$row['blogger_username'].'</td>';
		echo'<td>';
		if($row['blogger_is_active']==1){
			echo"Yes";
		}
		else{
			echo"No";
		}
		echo'</td>';
		echo'<td>'.$row['blogger_creation_date'].'</td>';
		echo'<td>';echo'<a href="mailto:'.$row['blogger_email'].'?Subject=Hello" target="_top">'.$row['blogger_email'].'</a>';echo'</td>';
		echo'<td>';
		echo '<div>';
		echo'<div class="left">';
		if($row['admin']==0){
		echo '<form name="myForm4" enctype="multipart/form-data" onsubmit="" action="delete_account_admin.php" method="post">';
		echo '<input type="hidden" name="blogid" value='.$row["blogger_id"].'>';
		echo '<input class="verifyblog" type="submit"value="Del Account" name="DelAcc"/>';
		echo "</form>";
		echo'</div>';
		
		echo'<div class="right">';
		echo '<form name="myForm4" enctype="multipart/form-data" onsubmit="" action="delete_all_account_admin.php" method="post">';
		echo '<input type="hidden" name="blogid" value='.$row["blogger_id"].'>';
		echo '<input class="verifyblog" type="submit"value="Del All" name="DeleteAll"/>';
		
		echo "</form>";
		}
		else {
			echo '<p style="color:red; font-weight:bold;">Cannot delete this account</p>';
		}
		echo'</div>';
		echo '</div>';
		echo'</td>';
		
	  echo'</tr>';
  }
  echo '</table>';

?>


</body>
</html>