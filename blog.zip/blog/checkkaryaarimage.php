<html>
<body>
<?php
$con = mysqli_connect("localhost","root","","blog");
mysqli_select_db($con, "blog") or die("Could not find DB");
        if (isset($_POST['Displayblog']))
        {
        $image = $_FILES['image'] ;
        echo $image;
        $name = $_FILES['image']['name'] ;
        $image = addslashes(file_get_contents($_FILES['image']['tmp_name'])) ; 
        $query = "INSERT INTO blog_detail (name, blog_detail_image) VALUES ('{$name}', '{$image}')"; 
        $result = mysqli_query($con, $query)  or die('something wrong' . mysql_error());    
        $id = (int) mysqli_insert_id($result);
      //  header('Location: image_view.php?id=' . $id);
        exit;
        }
?>
</body>
</html>