<?php
session_start();
?>
<html>
<body>
<?php

$bloggerid=$_POST['blogid'];
$con = mysqli_connect("localhost","root","","blog");
if (!$con)
  {
  die('Could not connect: ' . mysqli_error());
  }

  $query="SELECT blog_id FROM blog_master WHERE blogger_id='$bloggerid'";
  $result= mysqli_query($con,$query);
  
  $namequery="SELECT blogger_username FROM blogger_info WHERE blogger_id='$bloggerid'";
  $nameresult= mysqli_query($con,$namequery);
  $namerow=mysqli_fetch_assoc($nameresult);
  $blogger_name=$namerow['blogger_username'];
  
  while($row=mysqli_fetch_assoc($result))
  {
	  $blogid=$row['blog_id'];
	  $delquery="DELETE FROM blog_detail WHERE blog_id='$blogid'";
	  $delresult= mysqli_query($con,$delquery);
  }
  $queryblogmaster= "DELETE FROM blog_master WHERE blogger_id='$bloggerid'";
  $delblogmasterresult= mysqli_query($con,$queryblogmaster);
  
  $querybloggerinfo= "DELETE FROM blogger_info WHERE blogger_id='$bloggerid'";
  $delbloggerinforesult= mysqli_query($con,$querybloggerinfo);
  

  $querycheckblog= "DELETE FROM check_blog WHERE blogger_name='$blogger_name'";
  $checkblogresult= mysqli_query($con,$querycheckblog);
  
  $querytemptable= "DELETE FROM temp_table WHERE blogger_name='$blogger_name'";
  $temptableresult= mysqli_query($con,$querytemptable);
  
  header("location:viewbloggers.php");
  
mysqli_close($con);
?>

</body>
</html>
