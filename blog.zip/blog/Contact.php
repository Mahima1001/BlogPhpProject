<?php
session_start();
?>

<html>
<head>

<style>
body{
	background : url(images/background.jpg);
	background-size: 100% 100%;
}
.error{
			color:red;
		}
		body{
			background-repeat:no-repeat;
			background-size:100%;
			background-attachment:fixed;
		}
		.sub2{
			background-color:#663500;
			color:white;
			padding:20px;
			padding-right:50px;
			padding-left:50px;
			margin:auto;
			width:20%;
			border-width:5px;
			border-color:white;
		}
		#sub1{
			
			color:#663500;
			margin-left:auto;
			margin-right:auto;
		}
		.inputclass{
			width:100%;
			margin:auto;
			height:34px;
			border-radius:5px;
		}
		
		.txtclass{
			border-radius:5px;
		}
	
</style>

<script type="text/javascript">
		function validateForm2() {
			var re=/^[\w]+$/;
			var me=/^[A-Za-z]{1}[0-9]{2}[A-Za-z]{2}[0-9]{3}$/;
			var x = document.getElementById("B").value;
			var y = document.getElementById("C").value;
			var x2 = document.forms["myForm"]["email"].value;
			var atpos = x2.indexOf("@");
			var dotpos = x2.lastIndexOf(".");
			
   			if (x == null || x == "") {
        		alert("USER_NAME must be filled out");
        		return false;
   			}
			else if(!re.test(x))
			{
				alert("Error:USER_NAME contains INVALID characters");
				return false;
			}
				
			else if (atpos<1 || dotpos<atpos+2 || dotpos+2>=x2.length) {
				alert("Not a valid e-mail address");
				return false;
			}
			else{
				return true;
			}
		}
		
	</script>

<body>

	<?php
	if(strcmp($_SESSION['sameemail'],"Same Email")==0)
	{
		?><script>alert("Email ID already used");</script><?php
		$_SESSION['sameemail']="";
	}
	
	if(strcmp($_SESSION['sameemail'],"Done")==0)
	{
		?><script>alert("Send Successfully");</script><?php
		$_SESSION['sameemail']="";
	}
	
	?>
		<form name="myForm2" onsubmit="" action="mainpage.php" method="post">
		<input type="submit"value="Back" name="Back"/>
		</form>
	
		<H1 align="center" id="sub1" style="color: darkbrown"><B><U>SEND YOUR INFORMATION</B></U></H1>
		<p  align="center" id="sub1"><b>The field with ' <span style = "color:#ff0000">*</span> ' mark is required</b></p>
		<form name="myForm" onsubmit="return validateForm2()" action="insertcontact.php" method="post">
		<input type="hidden" name="submitted" value="true" />
		
			<div class="sub2" >
			
				
				
					 Name<span class="error">*</span><br>
					
				 <input type="text" class="inputclass" name="name" id="B" value='' required/><br><br><br>
			
			
					Phone No.<br>
						 <input type="text" class="inputclass" name="phnno" id="C"/><br><br><br>
					
					
						Email<span class="error">*</span> <br>
							 <input type="text" name="email" class="inputclass" required/> <br><br><br>
							 
							 
						Query<span class="error">*</span> <br>
							 <textarea class="txtclass"  name="blogdesc" rows=7 cols=33  id="blogdesc" required/></textarea> <br><br>
							 
			<p align="center">
				<input type="submit"value="Send Info" name="SendInfo"/>
				<input type="reset" value="Reset" />
			</p>
			</div>
		</form>
		
		
		

</body>
</html>