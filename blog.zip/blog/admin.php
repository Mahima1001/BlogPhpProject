<?php 
session_start();
if(!isset($_SESSION['username'])){
	header("location:mainpage.php");
	exit();
}
?>

<html>
<head>

<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	
	
<style>
	body{
	background : url(images/background.jpg);
	background-size: 100% 100%;
	background-attachment: fixed;
}
	
	#header{
		text-align:center;
		color: darkbrown;
		 font: 85% Arial, Sans-Serif;
		 font-size:40px;
		 font-weight:bold;
	}
	
	#preheader{
		float:right;
		margin-right:10px;
		margin-top:30px;
		
	}
	
	#footer{
		font-size:20px;
		list-style:none;
		color:#663500;
		margin-top:20px;
		width:15%;
		float:left;
		margin-left:7%;
		position:fixed;
		
	}
	#footerli{
		color:#663500;
		margin-bottom:25px;
	
	}
	#footer li a{
		text-decoration:none;
		color:white;
		font-weight:bold;
		font-size:20px;
		list-style:none;
		
	}
	
	#footer ul{
		list-style:none;
	}
	#center{
		width:100%;
		height:100%;
	}
	
	#centerright{
		width:75%;
		height:100%;
		float:right;
		margin-right:10%;
	}
	
	.sub3{
			float:right;
			width:750px;
			height:100%;
			
		}
		
		.blogtitle{
			height:7%;
			padding:5px;
			font-weight:bold;
			font-size:20px;
			background-color:#8B4513;
			color:red;
		}
		
		.blogdesc{
			height:30%;
			padding:5px;
			background-color:#CD853F;
			color:white;
		}
		
		.image{
			height:58%;
			width:100%;
			position:relative;
			
			}
		
		.imagesize{
		max-width:100%;
		max-height:100%;
	}	
	
	h2{
		position: absolute; 
   top: 20px; 
   left: 0; 
   width: 100%; 
	}
	
	h2 span { 
   color: white; 
   font: bold  Helvetica, Sans-Serif; 
   letter-spacing: -1px;  
   background: rgb(0, 0, 0); /* fallback color */
   background: rgba(0, 0, 0, 0.7);
   padding: 10px; 
}

	h3{
		position: absolute; 
   top: 220px; 
   right: 0; 
   width: 100%; 
	}
	
	h4{
		position: absolute; 
   top: 270px; 
   right: 0; 
   float:right;
   width: 100%;
	font-size:5px;
	}
	
	h3 span { 
   color: white; 
   font:  Helvetica, Sans-Serif; 
   letter-spacing: -1px;  
   background: rgb(0, 0, 0); /* fallback color */
   background: rgba(0, 0, 0, 0.7);
   padding: 10px; 
   float:right;
   font-size:18px;
}

h4 span { 
   color: white; 
   font:  Helvetica, Sans-Serif; 
   letter-spacing: -1px;  
   background: rgb(0, 0, 0); /* fallback color */
   background: rgba(0, 0, 0, 0.7);
   padding: 2px; 
   float:right;
   font-size:18px;
}
	
	.verifyblogform{
		float:right;
		
	}

	.verifyblogbutton{
		background-color:#663500;
		height:40px;
		border-radius:20px;
		color:white;
		font-size:20px;
	}
	.allowORdeny{
		float:right;
		margin:5px;
	}
	
	.allowblog{
		background-color:#663500;
		color:white;
		padding:2px;
		width:58px;
		height:28px;
	}
</style>
</head>
<body>

<?php
$_SESSION['viewer']="hello";
?>

<?php
if(strcmp($_SESSION['deleted'],"deleted successfully")==0){
	?><script>alert("Deleted successfully");</script><?php
	$_SESSION['deleted']="Allow";
}
if(strcmp($_SESSION['deleted'],"not deleted successfully")==0){
	?><script>alert("Error in deleting!");</script><?php
	$_SESSION['deleted']="Allow";
}
if(strcmp($_SESSION['deletedblog'],"deleted successfully")==0){
	?><script>alert("Deleted successfully");</script><?php
	$_SESSION['deletedblog']="Allow";
}
if(strcmp($_SESSION['deletedblog'],"not deleted successfully")==0){
	?><script>alert("Error in deleting!");</script><?php
	$_SESSION['deletedblog']="Allow";
}

if(strcmp($_SESSION['edit_status'],"Edited Successfully")==0){
	?><script>alert("Your account has been updated successfully!");</script><?php
	$_SESSION['edit_status']="Allow";
}

?>

<div id ="main">
<div id ="header">
	<p> Welcome <?php echo $_SESSION['username'];?></p>
	<form class="verifyblogform" name="myForm" enctype="multipart/form-data" onsubmit="" action="" method="post">
	<input class="verifyblogbutton" type="submit"value="Blogs To Be Verfied" name="verifyblogs"/>
	<input class="verifyblogbutton" type="submit"value="Display My Blog" name="Displaymyblog"/>
	</form>
	<br>
	<br>
</div>
<div id="center">
<div id= "footer">
	<ul>
         <li id= "footerli"><a href="#"><span class="glyphicon glyphicon-home" style= "color:#ff0000"></span>Home</a></li>
		  <li id= "footerli"><a href="addblog.php"><span class="glyphicon glyphicon-plus" style= "color:#ff0000"></span>Add Blog</a></li>
          <li id= "footerli"><a href="articles.php"><span class="glyphicon glyphicon-book" style= "color:#ff0000"></span>Articles</a></li>
          <li id= "footerli"><a href="edit_profile.php"><span class="glyphicon glyphicon-pencil" style= "color:#ff0000"></span>Edit Profile</a></li>
		  <li id= "footerli"><a href="myInfo.php"><span class="glyphicon glyphicon-user" style= "color:#ff0000"></span>My Info</a></li>
		  <li id= "footerli"><a href="viewercontact.php"><span class="glyphicon glyphicon-zoom-in" style= "color:#ff0000"></span>Viewer's Contact</a></li>
		  <li id= "footerli"><a href="viewbloggers.php"><span class="glyphicon glyphicon-zoom-in" style= "color:#ff0000"></span>Blogger's Info</a></li>
		  <li id= "footerli"><a href="logout.php"><span class="glyphicon glyphicon-off" style= "color:#ff0000"></span>LogOut</a></li>
        </ul>
</div>
<div id="centerright">
<?php

if(isset($_POST['Displaymyblog'])){
	$conn = mysqli_connect("localhost","root","","blog");
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$username= $_SESSION['username'];
$sql2="SELECT blogger_id from blogger_info where blogger_username='$username'";
$result2=mysqli_query($conn,$sql2);
$row2 = mysqli_fetch_assoc($result2);
$bloggeridfromblogger_info=$row2["blogger_id"];
$sql = "SELECT blog_id,blog_title, blog_desc,blog_category, blog_author,blog_day,updated_date FROM blog_master where blogger_id= '$bloggeridfromblogger_info'";
$result=mysqli_query($conn,$sql);

if (mysqli_num_rows($result) > 0) {
    while($row = mysqli_fetch_assoc($result)) {
echo '<div class="sub3">';
				echo '<div class="image">';
				$blogid= $row["blog_id"];
				$image_query= "SELECT blog_detail_image FROM blog_detail where blog_id='$blogid'";
				$image_result=mysqli_query($conn,$image_query);
				$image_row = mysqli_fetch_assoc($image_result);
				echo '<img style="width:100%; height:100%;" src="' . $image_row["blog_detail_image"] . ' " alt="Your Image"/>';
						echo '<h2><span>'.$row["blog_category"].'</span></h2>';
							echo '<h3><span>'.$row["blog_author"].'</span></h3>';
							echo '<h4><span>'.$row["updated_date"].' '.$row["blog_day"].'</span></h4>';
					echo "</div>";
				echo '<div class="blogtitle">';
					echo $row["blog_title"];
				echo "</div>";
				echo '<div class="blogdesc">';
					echo $row["blog_desc"];
				echo "</div>";
				
				echo "<div>";
					echo  '<div class="allowORdeny">';
				echo '<form name="myForm2" enctype="multipart/form-data" onsubmit="" action="delete.php" method="post">';
							echo '<input type="hidden" name="blogid" value='.$row["blog_id"].'>';
							echo '<input class="allowblog" type="submit" value="Delete" name="deleteblog"/>';
						echo "</form>";
					echo "</div>";
					echo '<div class="allowORdeny">';
						echo '<form name="myForm3" enctype="multipart/form-data" onsubmit="" action="edit.php" method="post">';
							echo '<input type="hidden" name="blogid" value='.$row["blog_id"].'>';
							echo '<input class="allowblog" type="submit" value="Edit" name="editblog"/>';
						echo "</form>";
					echo "</div>";
		echo "<br>";
		echo "<br>";
		echo "<br>";
				}
	echo "</div>";
			
	}

mysqli_close($conn);
}

else{
$conn = mysqli_connect("localhost","root","","blog");
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
$sql = "SELECT blogger_name, blog_id, blog_category, blog_author,blog_image,blog_title, blog_desc, blog_date, blog_day FROM check_blog";
$result = mysqli_query($conn, $sql);
if (mysqli_num_rows($result) > 0) {
    while($row = mysqli_fetch_assoc($result)) {
echo '<div class="sub3">';
				echo '<div class="image">';
				echo '<img style="width:100%; height:100%;" src="' . $row["blog_image"] . ' " alt="Your Image"/>';
						echo '<h2><span>'.$row["blog_category"].'</span></h2>';
							echo '<h3><span>'.$row["blog_author"].'</span></h3>';
							echo '<h4><span>'.$row["blog_date"]. " " .$row["blog_day"].'</span></h4>';
					echo "</div>";
				echo '<div class="blogtitle">';
					echo $row["blog_title"];
				echo "</div>";
				echo '<div class="blogdesc">';
					echo $row["blog_desc"];
				echo "</div>";
				
				echo "<div>";
					echo  '<div class="allowORdeny">';
					
						$insert_blog_id=$row["blog_id"];
						$insert_blogger_name=$row["blogger_name"];
						$insert_blog_category=$row["blog_category"];
						$insert_blog_author=$row["blog_author"];
						$insert_blog_image=$row["blog_image"];
						$insert_blog_title=$row["blog_title"];
						$insert_blog_desc=$row["blog_desc"];
						$insert_blog_date=$row["blog_date"];
						$insert_blog_day=$row["blog_day"];
						
					
						$con = mysqli_connect("localhost","root","","blog");
						if (!$con)
						{
							die('Could not connect: ' . mysqli_error());
						}
						
						$insert_query="INSERT INTO temp_table(blog_id,blogger_name,blog_title,blog_desc,blog_category,blog_author,blog_date,blog_day,blog_image) values('$insert_blog_id','$insert_blogger_name','$insert_blog_title','$insert_blog_desc','$insert_blog_category','$insert_blog_author','$insert_blog_date','$insert_blog_day','$insert_blog_image')";
						$insert_result=mysqli_query($con,$insert_query);
						mysqli_close($con);
						
						echo '<form name="myForm2" enctype="multipart/form-data" onsubmit="" action="allow.php" method="post">';
							echo '<input type="hidden" name="blogid" value='.$row["blog_id"].'>';
							echo '<input class="allowblog" type="submit" value="Allow" name="AllowBlog"/>';
						echo "</form>";
					echo "</div>";
					echo '<div class="allowORdeny">';
						echo '<form name="myForm3" enctype="multipart/form-data" onsubmit="" action="denied.php" method="post">';
							echo '<input type="hidden" name="blogid" value='.$row["blog_id"].'>';
							echo '<input class="allowblog" type="submit" value="Deny" name="DenyBlog"/>';
						echo "</form>";
					echo "</div>";
		echo "<br>";
		echo "<br>";
		echo "<br>";
				}		
			echo "</div>";
			
	}

mysqli_close($conn);
}

?>

</div>
</div>
</div>
</body>
</html>

