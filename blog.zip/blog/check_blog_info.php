<?php
session_start();
?>
<html>
<body>
<?php
$con = mysqli_connect("localhost","root","","blog");
if (!$con)
  {
  die('Could not connect: ' . mysqli_error());
  }
  
  $name= $_SESSION['blog_username'];
  $category=$_SESSION['blog_category'];
  $title=$_SESSION['blog_title'];
  $desc=$_SESSION['blog_desc'];
  $author=$_SESSION['blog_author'];
  $day= $_SESSION['blog_day'];
  $image=$_SESSION['image'];
  $sqlinsert="INSERT INTO check_blog(blogger_name,blog_category,blog_title,blog_desc,blog_author,blog_date,blog_day,blog_image,updated) VALUES ('$name','$category','$title','$desc','$author',CURDATE(),'$day','$image',0)";
  if(!mysqli_query($con,$sqlinsert)){
	 die('error inserting new record') ;
	  
  }else
  
  {
	  header("location:addblog.php");
}
 
mysqli_close($con);
?>

</body>
</html>
