<?php
session_start();

?>

<html>
<head>
<style>
body{
	background : url(images/background.jpg);
	background-size: 100% 100%;
}
.error{
			color:red;
		}
		body{
			background-repeat:no-repeat;
			background-size:100%;
			background-attachment:fixed;
		}
		.sub2{
			background-color:#663500;
			color:white;
			padding:20px;
			padding-right:50px;
			padding-left:50px;
			width:25%;
			border-width:5px;
			border-color:white;
			float:left;
			border-width:5px;
			height:80%;
		}
		#sub1{
			
			color:#663500;
			margin-top:50px;
			
		}
		.inputclass{
			width:180px;
			margin:auto;
			height:34px;
			border-radius:5px;
		}
		
		.sub3{
			float:right;
			width:50%;
			margin-right:10%;
			height:100%;
		}
		.sub4{
			width:100%;
			height:90%;
		}
		.blogcategory{
			width:40%;
			height:5%;
			opacity: 0.5;
			filter: alpha(opacity=50);
			float:left;
			padding:5px;
			margin-top:3%;
			position:absolute;
			z-index: 1000;
		}
		
		.blogtitle{
			height:7%;
			padding:5px;
			font-weight:bold;
			font-size:20px;
			background-color:#8B4513;
			color:red;
		}
		
		.blogdesc{
			height:30%;
			padding:5px;
			background-color:#CD853F;
			color:white;
		}
		
		.blogauthor{
			width:100%;
			height:30%;
			float:right;
			
			
		}
		
		.blogdate{
			width:100%;
			height:30%;
			float:right;
			margin-top:5%;
			
			
		}
		.image{
			height:58%;
			width:100%;
			position:relative;
			
			}
		
		.authoranddate{
			width:26%;
			height:8%;
			float:right;
			margin-top:45%;
			
		}
		
		.descclass{
			width:240px;
			height:120px;
			border-radius:5px;
		}
		
	.verifyblog{
		float:right;
		background-color:red;
		color:white;
		font-weight:bold;
		margin-right:12%;
	}
	
	.imagesize{
		max-width:100%;
		max-height:100%;
	}	
	
	h2{
		position: absolute; 
   top: 20px; 
   left: 0; 
   width: 100%; 
	}
	
	h2 span { 
   color: white; 
   font: bold  Helvetica, Sans-Serif; 
   letter-spacing: -1px;  
   background: rgb(0, 0, 0); /* fallback color */
   background: rgba(0, 0, 0, 0.7);
   padding: 10px; 
}

	h3{
		position: absolute; 
   top: 220px; 
   right: 0; 
   width: 100%; 
	}
	
	h4{
		position: absolute; 
   top: 270px; 
   right: 0; 
   float:right;
   width: 100%;
	font-size:5px;
	}
	
	h3 span { 
   color: white; 
   font:  Helvetica, Sans-Serif; 
   letter-spacing: -1px;  
   background: rgb(0, 0, 0); /* fallback color */
   background: rgba(0, 0, 0, 0.7);
   padding: 10px; 
   float:right;
   font-size:18px;
}

h4 span { 
   color: white; 
   font:  Helvetica, Sans-Serif; 
   letter-spacing: -1px;  
   background: rgb(0, 0, 0); /* fallback color */
   background: rgba(0, 0, 0, 0.7);
   padding: 2px; 
   float:right;
   font-size:18px;
}
	

</style>

</head>
<body>

<?php
$blogid= $_POST['blogid'];
$con = mysqli_connect("localhost","root","","blog");
if (!$con)
  {
  die('Could not connect: ' . mysqli_error());
  }
  
  $query= "SELECT blog_title,blog_desc,blog_category,blog_author FROM blog_master WHERE blog_id='$blogid'";
  $result=mysqli_query($con,$query);
  $row = mysqli_fetch_assoc($result);
  
  $query2= "SELECT blog_detail_image FROM blog_detail WHERE blog_id='$blogid'";
  $result2=mysqli_query($con,$query2);
  $row2 = mysqli_fetch_assoc($result2);
  
  $old_title= $row["blog_title"];
  $old_desc= $row["blog_desc"];
  $old_category= $row["blog_category"];
  $old_author= $row["blog_author"];
  $old_image=$row2["blog_detail_image"];
  $_SESSION['old_title']=$old_title;
?>

<form name="myForm2" enctype="multipart/form-data" onsubmit="" action="" method="post">
		<input type="hidden" name="blogid" value='<?php echo $blogid;?>'/>

<H1 align="center" id="sub1" style="color: darkbrown"><B><U>Blog Information</B></U></H1>
		<p id="sub1"><b>The field with ' <span style = "color:#ff0000">*</span> ' mark is required</b></p>
		<form name="myForm" enctype="multipart/form-data" onsubmit="" action="" method="post">
		<input type="hidden" name="submitted" value="true" />
			<div class= "sub4">
			<div class="sub2" >
			
				<table>
					<tr>
						<td>Title<span class="error">*</span></td>
						<td><input type="text" class="inputclass" name="blogtitle" id="B" value='<?php echo $old_title;?>' onFocus="this.value=''" required/></td>
					</tr>
					<tr></tr>
					<tr></tr>
					<tr></tr>
					<tr></tr>
					<tr></tr>
					<tr></tr>
					<tr></tr>
					
					
				
					
					<tr>
						<td>Category<span class="error">*</span> </td>
						<td> <input type="text" name="blogcategory" value='<?php echo $old_category;?>' class="inputclass" required/></td>
					</tr>
					<tr></tr>
					<tr></tr>
					<tr></tr>
					<tr></tr>
					<tr></tr>
					<tr></tr>
					<tr></tr>
					
					
					<tr>
						<td>Author<span class="error">*</span> </td>
						<td><input type="text" name="blogauthor" value='<?php echo $old_author;?>' class="inputclass" required/> </td>
					</tr>
					<tr></tr>
					<tr></tr>
					<tr></tr>
					<tr></tr>
					<tr></tr>
					<tr></tr>
					<tr></tr>
					
					<tr>	
						<td>Description<span class="error">*</span> </td>
						<td> <textarea class="descclass"  name="blogdesc" rows=7 cols=50  id="C" required/><?php echo $old_desc;?></textarea></td>
					</tr>
					<tr></tr>
					<tr></tr>
					<tr></tr>
					<tr></tr>
					<tr></tr>
					<tr></tr>
					<tr></tr>
					<tr><td></td>
					<td>
					<input type= "file" name="image" required/>
					
					</tr>
					<tr></tr>
					<tr></tr>
					<tr></tr>
					<tr></tr>
					<tr></tr>
					<tr></tr>
					<tr></tr>
					<tr></tr>
					<tr></tr>
					<tr></tr>
					<tr></tr>
					<tr></tr>
					<tr></tr>
					<tr></tr>
					<tr></tr>
					<tr>
						<td><input type="submit"value="Display Blog" name="Displayblog"/></td>
						<td><input type="reset" value="Reset" /></td>
					</tr>
					
					
				</table>
				</form>
				</div>;
				<?php
				if(isset($_POST['Displayblog'])){
				$_SESSION["blog_username_edit"]=$_SESSION['username'];
				$_SESSION["blog_title_edit"]= $_POST['blogtitle'];
				$_SESSION["blog_category_edit"]= $_POST['blogcategory'];
				$_SESSION["blog_desc_edit"]= $_POST['blogdesc'];
				$_SESSION["blog_author_edit"]= $_POST['blogauthor'];
				$_SESSION["blog_date_edit"]= date("Y/m/d");
				$_SESSION["blog_day_edit"]= date("l");
				$title= $_POST['blogtitle'];
				
				$con = mysqli_connect("localhost","root","","blog");
			if (!$con)
			{
				die('Could not connect: ' . mysqli_error());
			}
			
			if(strcmp($title,$old_title)==0)
			{
				echo '<div class="sub3">';
				echo '<div class="image">';
				 $aExtraInfo = getimagesize($_FILES['image']['tmp_name']);
				$sImage = "data:" . $aExtraInfo["mime"] . ";base64," . base64_encode(file_get_contents($_FILES['image']['tmp_name']));
				echo '<img style="width:100%; height:100%;" src="' . $sImage . ' " alt="Your Image"/>';
				$_SESSION["image_edit"]=$sImage;
						echo '<h2><span>'.$_POST['blogcategory'].'</span></h2>';
							echo '<h3><span>'.$_POST['blogauthor'].'</span></h3>';
							echo '<h4><span>'.date("Y/m/d")." ".date("l").'</span></h4>';
					echo "</div>";
				echo '<div class="blogtitle">';
					echo $_POST['blogtitle'];
				echo "</div>";
				echo '<div class="blogdesc">';
					echo $_POST['blogdesc'];
				echo "</div>";
			echo "</div>";
			echo "</div> ";
			echo '<form name="myForm2" enctype="multipart/form-data" onsubmit="" action="edit_blog_info.php" method="post">';
		echo '<input class="verifyblog" type="submit"value="Verify Blog" name="Verifyblog"/>';
		echo "</form>";
			}
			else
			{
			$query="SELECT blog_title FROM check_blog where blog_title='$title'";
			$result=mysqli_query($con,$query);
			$num=mysqli_num_rows($result);
			
			$query2="SELECT blog_title FROM blog_master where blog_title='$title'";
			$result2=mysqli_query($con,$query2);
			$num2=mysqli_num_rows($result2);
			
			if($num > 0)
			{
				?><script>alert("Title must be unique");</script><?php
			}
			
			else if($num2>0)
			{
				?><script>alert("Title must be unique");</script><?php
			}
			else{
			
			echo '<div class="sub3">';
				echo '<div class="image">';
				 $aExtraInfo = getimagesize($_FILES['image']['tmp_name']);
				$sImage = "data:" . $aExtraInfo["mime"] . ";base64," . base64_encode(file_get_contents($_FILES['image']['tmp_name']));
				echo '<img style="width:100%; height:100%;" src="' . $sImage . ' " alt="Your Image"/>';
				$_SESSION["image_edit"]=$sImage;
						echo '<h2><span>'.$_POST['blogcategory'].'</span></h2>';
							echo '<h3><span>'.$_POST['blogauthor'].'</span></h3>';
							echo '<h4><span>'.date("Y/m/d")." ".date("l").'</span></h4>';
					echo "</div>";
				echo '<div class="blogtitle">';
					echo $_POST['blogtitle'];
				echo "</div>";
				echo '<div class="blogdesc">';
					echo $_POST['blogdesc'];
				echo "</div>";
			echo "</div>";
			echo "</div> ";
			echo '<form name="myForm2" enctype="multipart/form-data" onsubmit="edit_blog_info.php" action="edit_blog_info.php" method="post">';
		echo '<input class="verifyblog" type="submit"value="Verify Changes" name="Verifychanges"/>';
		echo "</form>";
				}
				}
				}
			
	?>
	
	
		
		
</body>
</html>