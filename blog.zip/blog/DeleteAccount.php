<?php
session_start();
if(!isset($_SESSION['username'])){
	header("location:mainpage.php");
	exit();
}
?>
<html>
<body>
<?php

$bloggername=$_SESSION['username'];

$con = mysqli_connect("localhost","root","","blog");
if (!$con)
  {
  die('Could not connect: ' . mysqli_error());
  }

  $userquery="SELECT blogger_id FROM blogger_info WHERE blogger_username='$bloggername'";
  $userresult= mysqli_query($con,$userquery);
  $userrow=mysqli_fetch_assoc($userresult);
  $bloggerid= $userrow['blogger_id'];
  
  $query="SELECT blog_id FROM blog_master WHERE blogger_id='$bloggerid'";
  $result= mysqli_query($con,$query);

  
  while($row=mysqli_fetch_assoc($result))
  {
	  $blogid=$row['blog_id'];
	  $delquery="DELETE FROM blog_detail WHERE blog_id='$blogid'";
	  $delresult= mysqli_query($con,$delquery);
  }
  $queryblogmaster= "DELETE FROM blog_master WHERE blogger_id='$bloggerid'";
  $delblogmasterresult= mysqli_query($con,$queryblogmaster);
  
  $querybloggerinfo= "DELETE FROM blogger_info WHERE blogger_id='$bloggerid'";
  $delbloggerinforesult= mysqli_query($con,$querybloggerinfo);
  

  $querycheckblog= "DELETE FROM check_blog WHERE blogger_name='$bloggername'";
  $checkblogresult= mysqli_query($con,$querycheckblog);
  
  $querytemptable= "DELETE FROM temp_table WHERE blogger_name='$bloggername'";
  $temptableresult= mysqli_query($con,$querytemptable);
  header("location:logout.php");
  
mysqli_close($con);
?>

</body>
</html>
